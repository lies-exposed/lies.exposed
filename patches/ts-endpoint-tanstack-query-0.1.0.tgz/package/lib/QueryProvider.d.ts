import { type EndpointsMapType } from '@ts-endpoint/core';
import { type API } from '@ts-endpoint/resource-client';
import { type CustomQueryOverride, type QueryProviderOverrides, type ResourceEndpointsQueriesOverride } from './QueryProviderOverrides.js';
import { type GetQueryProviderImplAt, type QueryProvider, type ResourceQuery } from './types.js';
type PatchedQueryProvider<ES extends EndpointsMapType, O extends Record<string, any>> = QueryProvider<ES> & {
    [K in keyof QueryProviderOverrides<ES, O>]: QueryProviderOverrides<ES, O>[K] extends ResourceEndpointsQueriesOverride<ES, any, any, infer CC> ? {
        Custom: {
            [KK in keyof CC]: CC[KK] extends CustomQueryOverride<ES, infer P, infer Q, infer O> ? ResourceQuery<P, unknown, Q, O> : GetQueryProviderImplAt<ES, K, KK>;
        };
    } : GetQueryProviderImplAt<ES, K>;
};
export type EndpointsQueryProvider<ES extends EndpointsMapType, O extends Record<string, any>> = PatchedQueryProvider<ES, O>;
declare const CreateQueryProvider: <ES extends EndpointsMapType, O extends Record<string, any>>(resourceClient: API<ES>, overrides?: QueryProviderOverrides<ES, O>) => EndpointsQueryProvider<ES, O>;
export { CreateQueryProvider, type QueryProvider };
