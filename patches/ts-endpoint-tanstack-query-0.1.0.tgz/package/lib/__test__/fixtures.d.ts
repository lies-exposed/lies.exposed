import { type EndpointOutputType, type EndpointParamsType } from '@ts-endpoint/core';
import { type API } from '@ts-endpoint/resource-client';
import { type TestEndpoints } from '@ts-endpoint/test';
import { type CustomQueryOverride, type QueryProviderOverrides, type ResourceEndpointsQueriesOverride } from '../QueryProviderOverrides.js';
import { type ResourceQuery } from '../types.js';
/**
 * A custom query override for testing that returns an actor list with id 'OV'.
 * Returns the same shape as Actor.List endpoint: { data: Actor[], total: number }
 */
export declare const ActorTestOverride: CustomQueryOverride<TestEndpoints, EndpointParamsType<typeof TestEndpoints.Actor.Get>, EndpointParamsType<typeof TestEndpoints.Actor.Get>, EndpointOutputType<typeof TestEndpoints.Actor.List>>;
/**
 * Resource overrides for Actor endpoints.
 */
export declare const ActorResourceOverrides: ResourceEndpointsQueriesOverride<TestEndpoints, undefined, undefined, {
    Test: typeof ActorTestOverride;
}>;
/**
 * Query provider overrides for testing.
 */
export declare const TestQueryProviderOverrides: QueryProviderOverrides<TestEndpoints, {
    Actor: typeof ActorResourceOverrides;
}>;
/**
 * Custom query override for GetSiblings that returns a list with a single sibling.
 * Uses List output type to include total count.
 */
export declare const GetSiblingsOverride: CustomQueryOverride<TestEndpoints, EndpointParamsType<typeof TestEndpoints.Actor.Custom.GetSiblings>, undefined, EndpointOutputType<typeof TestEndpoints.Actor.List>>;
/**
 * Resource overrides for Actor including GetSiblings custom override.
 * Uses actual endpoint types for Get and List to satisfy toOverrideQueries type constraints.
 */
export declare const ActorSiblingsResourceOverrides: ResourceEndpointsQueriesOverride<TestEndpoints, typeof TestEndpoints.Actor.Get, typeof TestEndpoints.Actor.List, {
    GetSiblings: typeof GetSiblingsOverride;
}>;
/**
 * Mock API that returns the GetSiblings override via Actor.Custom.GetSiblings.
 */
export declare const mockApiForOverrides: API<TestEndpoints>;
/**
 * Type for the result of toOverrideQueries with GetSiblings custom query.
 * This provides proper typing for the Custom.GetSiblings resource query.
 */
export interface ActorSiblingsOverrideQueries {
    Custom?: {
        GetSiblings: ResourceQuery<EndpointParamsType<typeof TestEndpoints.Actor.Custom.GetSiblings>, undefined, EndpointOutputType<typeof TestEndpoints.Actor.List>>;
    };
}
