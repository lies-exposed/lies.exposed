export declare const defaultUseQueryListParams: {
    pagination: {
        page: number;
        perPage: number;
    };
    sort: {
        field: string;
        order: "ASC";
    };
    filter: {};
};
