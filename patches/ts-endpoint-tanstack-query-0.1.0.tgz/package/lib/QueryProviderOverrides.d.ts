import { type EndpointParamsType, type EndpointsMapType, type IOError, type InferEndpointInstanceParams, type MinimalEndpointInstance, type PartialSerializedType, type EndpointQueryEncoded } from '@ts-endpoint/core';
import { type API } from '@ts-endpoint/resource-client';
import { type TaskEither } from 'fp-ts/lib/TaskEither.js';
import { type GetKeyFn, type ResourceQueries } from './types.js';
export interface GetQueryOverride<P, Q = undefined> {
    getKey?: GetKeyFn<P, Q>;
}
export type CustomQueryOverride<ES extends EndpointsMapType, P, Q, O> = (q: API<ES>) => (p: P, q: Q) => TaskEither<IOError, O>;
export interface ResourceEndpointsQueriesOverride<ES extends EndpointsMapType, G, L, CC> {
    get?: G extends MinimalEndpointInstance ? GetQueryOverride<EndpointParamsType<G>, PartialSerializedType<InferEndpointInstanceParams<G>['query']>> : never;
    list?: L extends MinimalEndpointInstance ? GetQueryOverride<EndpointParamsType<L>, Partial<EndpointQueryEncoded<L>>> : never;
    Custom?: {
        [K in keyof CC]: CC[K] extends CustomQueryOverride<ES, infer P, infer Q, infer O> ? CustomQueryOverride<ES, P, Q, O> : never;
    };
}
export type QueryProviderOverrides<ES extends EndpointsMapType, QO = Record<string, any>> = {
    [K in keyof QO]: QO[K] extends ResourceEndpointsQueriesOverride<ES, infer G, infer L, infer CC> ? ResourceEndpointsQueriesOverride<ES, G, L, CC> : never;
};
export declare const toOverrideQueries: <ES extends EndpointsMapType, G extends MinimalEndpointInstance, L extends MinimalEndpointInstance, CC extends Record<string, any>>(QP: API<ES>, namespace: string, e: ResourceEndpointsQueriesOverride<ES, G, L, CC>) => Partial<ResourceQueries<G, L, CC>>;
