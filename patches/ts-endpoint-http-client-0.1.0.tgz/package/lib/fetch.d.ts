import { type Codec, IOError, type MinimalEndpointInstance } from '@ts-endpoint/core';
import { type FetchClient, type GetHTTPClientOptions } from './GetHTTPClient.js';
import { type HTTPClientConfig } from './config.js';
declare module './HKT.js' {
    interface URItoKind<A> {
        IOError: A extends Record<string, Codec<any, any, never>> ? IOError<A> : never;
    }
}
export declare const GetFetchHTTPClient: <A extends {
    [key: string]: MinimalEndpointInstance;
}>(config: HTTPClientConfig, endpoints: A, options: GetHTTPClientOptions) => import("./GetHTTPClient.js").HTTPClient<A, "IOError">;
export declare const useBrowserFetch: <E extends MinimalEndpointInstance>(baseURL: string, e: E, options: GetHTTPClientOptions) => FetchClient<E, "IOError">;
