import { type TaskEither } from 'fp-ts/lib/TaskEither.js';
export declare const throwTE: <E, A>(te: TaskEither<E, A>) => Promise<A>;
