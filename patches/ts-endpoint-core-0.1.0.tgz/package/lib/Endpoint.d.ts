import { type Either } from 'fp-ts/lib/Either.js';
import { type RequiredKeys } from 'typelevel-ts';
import { type Codec, type EffectCodec, type EffectRecordCodec, type EncodedType, type IOTSCodec, type IOTSRecordCodec, type RecordCodec, type RecordCodecEncoded, type RecordCodecSerialized, type runtimeType, type serializedType, type UndefinedsToPartial } from './Codec.js';
import type { StreamOutputCodec } from './Codec.js';
export type HTTPMethod = 'OPTIONS' | 'HEAD' | 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
export type EndpointErrors<S extends string, B extends Codec<any, any>> = Record<S, B>;
/**
 * Represents an HTTP endpoint of our API
 */
export interface Endpoint<M extends HTTPMethod, O extends Codec<any, any>, H extends RecordCodec<any> | undefined, Q extends RecordCodec<any> | undefined, B extends Codec<any, any> | undefined, P extends RecordCodec<any> | undefined, E extends EndpointErrors<never, Codec<any, any>> | undefined> {
    getPath: [P] extends [undefined] ? (i?: undefined) => string : (args: runtimeType<P>) => string;
    Method: M;
    Errors?: E;
    Input?: [H, P, Q, B] extends [undefined, undefined, undefined, undefined] ? never : {
        Headers?: H;
        Params?: P;
        Query?: Q;
        Body?: M extends 'POST' | 'PUT' | 'PATCH' | 'DELETE' ? B : never;
    };
    Output: O extends StreamOutputCodec<infer A, infer B> ? StreamOutputCodec<A, B> : O;
}
export type MinimalEndpoint = Omit<Endpoint<HTTPMethod, Codec<any, any>, RecordCodec<any>, RecordCodec<any>, Codec<any, any>, RecordCodec<any>, EndpointErrors<never, Codec<any, any>>>, 'getPath'> & {
    getPath: (i?: any) => string;
};
export type InferEndpointParams<E> = E extends Endpoint<infer M, infer O, infer H, infer Q, infer B, infer P, infer E> ? {
    method: M;
    headers: H;
    params: P;
    query: Q;
    body: B;
    output: O;
    errors: E;
} : never;
/**
 * Data type representing an endpoint instance.
 **/
export type EndpointInstance<E extends MinimalEndpoint> = {
    /**
     * helper to get a path given a set of runtime params.
     *
     * @returns a string representation of a path instance
     * @example
     * ```
     * import { Endpoint } from '..';
     * import * as t from 'io-ts';
     *
     * const endpoint = Endpoint({
     *  Input: {
     *    Params: { id: t.number },
     *  },
     *  Method: 'GET',
     *  getPath: ({ id }) => `users/${id}/crayons`,
     *  Output: { crayons: t.array(t.string) },
     *});
     *
     * endpoint.getPath({ id: 3 })
     * // returns "users/3/crayons"
     * ```
     */
    getPath: E['getPath'];
    /**
     * helper to get a path version with static values in place of actual params.
     *
     * @returns a static representation of the path
     * @example
     * ```
     * import { Endpoint } from '..';
     * import * as t from 'io-ts';
     *
     * const endpoint = Endpoint({
     *  Input: {
     *    Params: { id: t.string },
     *  },
     *  Method: 'GET',
     *  getPath: ({ id }) => `users/${id}/crayons`,
     *  Output: { crayons: t.array(t.string) },
     *});
     *
     * endpoint.getStaticPath(param => `:${param}`) // returns "users/:id/crayons"
     * ```
     */
    getStaticPath: [E['Input']] extends [undefined] ? (i?: {}) => string : [InferEndpointParams<E>['params']] extends [undefined] ? (i?: {}) => string : (f: (paramName: keyof runtimeType<InferEndpointParams<E>['params']>) => string) => string;
    Method: E['Method'];
    Output: E['Output'];
} & (E['Input'] extends undefined ? {
    Input?: never;
} : {
    Input: (InferEndpointParams<E>['params'] extends undefined ? {
        Params?: never;
    } : {
        Params: NonNullable<InferEndpointParams<E>['params']>;
    }) & (InferEndpointParams<E>['headers'] extends undefined ? {
        Headers?: never;
    } : {
        Headers: NonNullable<InferEndpointParams<E>['headers']>;
    }) & (InferEndpointParams<E>['query'] extends undefined ? {
        Query?: never;
    } : {
        Query: NonNullable<InferEndpointParams<E>['query']>;
    }) & (InferEndpointParams<E>['body'] extends undefined ? {
        Body?: never;
    } : {
        Body: NonNullable<InferEndpointParams<E>['body']>;
    });
}) & (E['Errors'] extends undefined ? {
    Errors?: never;
} : {
    Errors: NonNullable<E['Errors']>;
});
/**
 * Constructor function for an endpoint
 * @returns an EndpointInstance
 */
export declare function Endpoint<M extends HTTPMethod, O extends Codec<any, any>, Q extends RecordCodec<any> | undefined = undefined, H extends RecordCodec<any> | undefined = undefined, B extends Codec<any, any> | undefined = undefined, P extends RecordCodec<any> | undefined = undefined, E extends EndpointErrors<never, Codec<any, any>> | undefined = undefined>(e: Endpoint<M, O, H, Q, B, P, E>): EndpointInstance<Endpoint<M, O, H, Q, B, P, E>>;
export type MinimalEndpointInstance = MinimalEndpoint & {
    getStaticPath: (f: (i?: any) => string) => string;
};
/**
 * Helper type for constructing the Body payload when calling an endpoint whose
 * Body schema is wrapped in a `filter` (e.g. `nonEmptyRecordFromType`).
 *
 * TypeScript cannot statically prove that an object literal satisfies a branded
 * filter constraint, so `TypeOfEndpointInstanceInput` can be hard to satisfy
 * without a cast in those cases. `BodyInput<E>` gives the plain partial encoded
 * type of the Body field, stripping any filter/brand wrappers.
 *
 * @example
 * ```typescript
 * import { type BodyInput } from '@ts-endpoint/core';
 *
 * const body: BodyInput<typeof ActorEdit> = { name: 'Alice' };
 * client.ActorEdit({ Body: body, Params: { id: '1' } });
 * ```
 */
export type BodyInput<E extends MinimalEndpointInstance> = E['Input'] extends {
    Body: Codec<any, any>;
} ? Partial<serializedType<NonNullable<E['Input']['Body']>>> : never;
export type TypeOfEndpointInstanceInput<E extends MinimalEndpointInstance> = [
    RequiredKeys<E['Input']>
] extends [never] ? void : {
    [K in keyof NonNullable<E['Input']>]: NonNullable<E['Input']>[K] extends Codec<any, any> ? UndefinedsToPartial<serializedType<NonNullable<E['Input']>[K]>> : never;
};
export type TypeOfEndpointInstance<E extends MinimalEndpointInstance> = {
    getPath: E['getPath'];
    getStaticPath: E['getStaticPath'];
    Method: E['Method'];
    Input: TypeOfEndpointInstanceInput<E>;
    Output: runtimeType<E['Output']>;
    Errors: {
        [K in keyof NonNullable<E['Errors']>]: NonNullable<E['Errors']>[K] extends RecordCodec<any> ? RecordCodecSerialized<NonNullable<E['Errors']>[K]> : NonNullable<E['Errors']>[K] extends Codec<any, any> ? runtimeType<NonNullable<E['Errors']>[K]> : never;
    };
};
export type EndpointInstanceEncodedInputs<E extends MinimalEndpointInstance> = [
    RequiredKeys<E['Input']>
] extends [never] ? void : {
    [K in keyof NonNullable<E['Input']>]: NonNullable<E['Input']>[K] extends Codec<any, any, any> ? runtimeType<NonNullable<E['Input']>[K]> : never;
};
export type EndpointInstanceEncodedParams<E extends MinimalEndpointInstance> = {
    getPath: E['getPath'];
    getStaticPath: E['getStaticPath'];
    Method: E['Method'];
    Input: EndpointInstanceEncodedInputs<E>;
    Output: runtimeType<E['Output']>;
    Errors: {
        [k in keyof NonNullable<E['Errors']>]: NonNullable<E['Errors']>[k] extends RecordCodec<any> ? RecordCodecEncoded<NonNullable<E['Errors']>[k]> : never;
    };
};
export type InferEndpointInstanceParams<EI> = EI extends EndpointInstance<infer E> ? InferEndpointParams<E> : never;
export type EndpointOutputType<L> = InferEndpointInstanceParams<L>['output'] extends StreamOutputCodec<any, any> ? NodeJS.ReadableStream : runtimeType<InferEndpointInstanceParams<L>['output']>;
export type EndpointDataOutputType<L, K extends string = 'data'> = L extends MinimalEndpointInstance ? InferEndpointInstanceParams<L>['output'] extends Codec<any, any> ? runtimeType<InferEndpointInstanceParams<L>['output']>[K] extends unknown[] ? runtimeType<InferEndpointInstanceParams<L>['output']> : runtimeType<InferEndpointInstanceParams<L>['output']>[K] : never : InferEndpointParams<L>['output'] extends Codec<any, any> ? runtimeType<InferEndpointParams<L>['output']>[K] extends unknown[] ? runtimeType<InferEndpointParams<L>['output']> : runtimeType<InferEndpointParams<L>['output']>[K] : never;
export type EndpointQueryType<G> = InferEndpointInstanceParams<G>['query'] extends undefined ? undefined : G extends MinimalEndpointInstance ? serializedType<InferEndpointInstanceParams<G>['query']> : serializedType<InferEndpointParams<G>['query']>;
export type EndpointParamsType<G> = G extends MinimalEndpointInstance ? InferEndpointInstanceParams<G>['params'] extends undefined ? undefined : serializedType<InferEndpointInstanceParams<G>['params']> : never;
export type EndpointQueryEncoded<L> = L extends MinimalEndpointInstance ? serializedType<InferEndpointInstanceParams<L>['query']> : serializedType<InferEndpointParams<L>['query']>;
type DecodeUnknown<C, E> = (e: unknown, overrideOptions?: any) => Either<E, EncodedType<C>>;
export type DecodeEffectCodec<E> = <C extends EffectCodec<any, any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type DecodeIOTSCodec<E> = <C extends IOTSCodec<any, any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type DecodeIOTSRecordCodec<E> = <C extends IOTSRecordCodec<any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type DecodeEffectRecordCodecFn<E> = <C extends EffectRecordCodec<any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type DecodeRecordCodecFn<E> = <C extends RecordCodec<any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type DecodeCodecFn<E> = <C extends Codec<any, any>>(c: C, parseOptions?: any) => DecodeUnknown<C, E>;
export type EndpointDecodeFn<E> = DecodeIOTSRecordCodec<E> | DecodeEffectRecordCodecFn<E> | DecodeIOTSCodec<E> | DecodeEffectCodec<E> | DecodeRecordCodecFn<E> | DecodeCodecFn<E>;
export {};
