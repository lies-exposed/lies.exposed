export declare class BaseError<D = any> extends Error {
    status: number;
    name: string;
    details?: D;
    stack?: string | undefined;
    constructor(status: number, message: string, details?: D);
}
