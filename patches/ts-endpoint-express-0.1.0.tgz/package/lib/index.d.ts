import { type Codec, type EndpointDecodeFn, type InferEndpointInstanceParams, IOError, type MinimalEndpointInstance, type runtimeType, type UndefinedOrRuntime } from '@ts-endpoint/core';
import { type StreamOutputCodec } from '@ts-endpoint/core';
import type * as express from 'express';
import { type Controller } from './Controller.js';
import { type Kind, type URIS } from './HKT.js';
export type ErrorMeta<E> = {
    message: string;
    errors?: E;
};
declare module './HKT.js' {
    interface URItoKind<A> {
        IOError: [A] extends [Record<string, Codec<any, any>>] ? IOError<A> : IOError<never>;
    }
}
type EndpointController<E extends MinimalEndpointInstance, M extends URIS = 'IOError'> = E['Output'] extends StreamOutputCodec<any, any> ? Controller<Kind<M, NonNullable<E['Errors']>>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['params']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['headers']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['query']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['body']>, runtimeType<InferEndpointInstanceParams<E>['output']>, true> : Controller<Kind<M, NonNullable<E['Errors']>>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['params']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['headers']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['query']>, UndefinedOrRuntime<InferEndpointInstanceParams<E>['body']>, runtimeType<InferEndpointInstanceParams<E>['output']>, false | undefined>;
export type AddEndpoint<M extends URIS = 'IOError'> = (router: express.Router, ...m: express.RequestHandler[]) => <E extends MinimalEndpointInstance>(endpoint: E, controller: EndpointController<E, M>) => void;
export type AddEndpoint2<M extends URIS = 'IOError'> = (router: express.Router, ...m: express.RequestHandler[]) => <E extends MinimalEndpointInstance>(endpoint: E) => (controller: EndpointController<E, M>) => void;
export declare const buildIOError: (errors: unknown) => IOError<never>;
interface GetEndpointSubscriberOptions<M extends URIS = 'IOError'> {
    decode: EndpointDecodeFn<Kind<M, unknown>>;
    buildDecodeError: (e: unknown) => Kind<M, unknown>;
}
/**
 * Adds an endpoint to your router.
 */
export declare const GetEndpointSubscriber: <M extends URIS = "IOError">({ buildDecodeError, decode, }: GetEndpointSubscriberOptions<M>) => AddEndpoint<M>;
export {};
