import { type AxiosInstance, type AxiosRequestConfig, type AxiosResponse } from 'axios';
import type * as RA from 'react-admin';
export interface APIRESTClient {
    client: AxiosInstance;
    request: <T = any>(config: AxiosRequestConfig<T>) => Promise<any>;
    get: <R = any>(url: string, params: any) => Promise<R>;
    put: <R = any>(url: string, data?: any) => Promise<AxiosResponse<R>>;
    post: <R = any>(url: string, data?: any) => Promise<AxiosResponse<R>>;
    getList: <R extends RA.RaRecord>(resource: string, params: RA.GetListParams) => Promise<RA.GetListResult<R>>;
    getOne: <R extends RA.RaRecord>(resource: string, params: RA.GetOneParams) => Promise<RA.GetOneResult<R>>;
    getMany: <R extends RA.RaRecord>(resource: string, params: RA.GetManyParams) => Promise<RA.GetManyResult<R>>;
    getManyReference: <R extends RA.RaRecord>(resource: string, params: RA.GetManyReferenceParams) => Promise<RA.GetManyReferenceResult<R>>;
    update: <R extends RA.RaRecord>(resource: string, params: RA.UpdateParams) => Promise<RA.UpdateResult<R>>;
    updateMany: (resource: string, params: RA.UpdateManyParams) => Promise<RA.UpdateManyResult>;
    create: <R extends Omit<RA.RaRecord, 'id'>>(resource: string, params: RA.CreateParams) => Promise<RA.CreateResult<R & {
        id: string;
    }>>;
    delete: <R extends RA.RaRecord>(resource: string, params: RA.DeleteParams) => Promise<RA.DeleteResult<R>>;
    deleteMany: (resource: string, params: RA.DeleteManyParams) => Promise<RA.DeleteManyResult>;
}
export declare const paramsToPagination: (start: number, end: number) => RA.GetListParams["pagination"];
export interface APIRESTClientCtx {
    url: string;
    getAuth?: () => string | null;
}
export declare const APIRESTClient: ({ getAuth, ...ctx }: APIRESTClientCtx) => APIRESTClient;
