import { IOError, type EndpointDecodeFn, type EndpointsMapType } from '@ts-endpoint/core';
import type * as E from 'fp-ts/lib/Either.js';
import * as TE from 'fp-ts/lib/TaskEither.js';
import type { GetListResult, GetOneResult } from 'react-admin';
import { type APIRESTClient } from './ApiRestClient.js';
import { type EndpointsRESTClient } from './types.js';
export declare const dataProviderRequestLift: <B extends {
    data: any;
}, E>(lp: () => Promise<GetOneResult<any>> | Promise<GetListResult<any>>, decode: <A>(a: A) => E.Either<E, B>) => TE.TaskEither<E | IOError, B>;
interface FromEndpointsOptions {
    decode: EndpointDecodeFn<IOError>;
}
declare const RAEndpointsClient: (apiClient: APIRESTClient, opts: FromEndpointsOptions) => <ES extends EndpointsMapType>(Endpoints: ES) => EndpointsRESTClient<ES>;
export { RAEndpointsClient };
