import { IOError, type EitherDecode, type EndpointDecodeFn, type EndpointInstance, type EndpointsMapType, type MinimalEndpointInstance, type ResourceEndpoints, type runtimeType, type TypeOfEndpointInstanceInput } from '@ts-endpoint/core';
import { type GetHTTPClientOptions } from '@ts-endpoint/http-client';
import type { AxiosInstance, AxiosResponse } from 'axios';
import * as TE from 'fp-ts/lib/TaskEither.js';
type FlattenBodyInput<T> = T extends {
    Body: {
        params: infer P;
    };
} ? Omit<T, 'Body'> & {
    Body: P;
} : never;
export type EndpointRequest<E extends MinimalEndpointInstance> = (input: TypeOfEndpointInstanceInput<E> | FlattenBodyInput<TypeOfEndpointInstanceInput<E>>) => TE.TaskEither<IOError, runtimeType<E['Output']>>;
export type EndpointREST<Get extends MinimalEndpointInstance, List extends MinimalEndpointInstance, Create extends MinimalEndpointInstance, Edit extends MinimalEndpointInstance, Delete extends MinimalEndpointInstance, Custom extends Record<string, MinimalEndpointInstance> | undefined> = {
    Get: EndpointRequest<Get>;
    List: EndpointRequest<List>;
    Create: EndpointRequest<Create>;
    Edit: EndpointRequest<Edit>;
    Delete: EndpointRequest<Delete>;
    Custom: Custom extends Record<string, MinimalEndpointInstance> ? {
        [K in keyof Custom]: Custom[K] extends EndpointInstance<infer E> ? EndpointRequest<EndpointInstance<E>> : never;
    } : undefined;
};
export type API<Endpoints extends EndpointsMapType> = {
    [K in keyof Endpoints]: Endpoints[K] extends ResourceEndpoints<infer Get, infer List, infer Create, infer Edit, infer Delete, infer CC> ? EndpointREST<Get, List, Create, Edit, Delete, CC> : never;
};
export declare const liftFetch: <A, B>(lp: () => Promise<AxiosResponse<A>>, decode: EitherDecode<B, IOError>) => TE.TaskEither<IOError, B>;
export declare const toEndpointRequest: <E extends MinimalEndpointInstance>(e: E) => (client: AxiosInstance, decode: EndpointDecodeFn<IOError>) => EndpointRequest<E>;
declare const GetResourceClient: <ES extends EndpointsMapType>(client: AxiosInstance, endpoints: ES, opts: GetHTTPClientOptions) => API<ES>;
export { GetResourceClient };
